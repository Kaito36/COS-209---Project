-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 29, 2020 at 12:30 PM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.3.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `oswebsite`
--

-- --------------------------------------------------------

--
-- Table structure for table `addtocart`
--

CREATE TABLE `addtocart` (
  `transactionid` int(255) NOT NULL,
  `productid` int(200) NOT NULL,
  `userid` int(200) NOT NULL,
  `price` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(200) NOT NULL,
  `type` varchar(150) NOT NULL,
  `pname` varchar(150) NOT NULL,
  `image` varchar(200) NOT NULL,
  `price` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `type`, `pname`, `image`, `price`) VALUES
(1, 'cpu', ' Intel Core i9 10900K', 'image\\core_i9_10900k_ryzen_3900x_corona.png', 600),
(2, 'cpu', 'Intel Core i9-10900X', 'image\\61mBrF1jNuL._AC_SL1500_.jpg', 975),
(3, 'gpu', 'AMD Raedon VII', 'image\\gpu1.jpg', 539.99),
(4, 'gpu', 'MSI GTX 1070', 'image\\gpu2.png', 339.99),
(5, 'Motherboard', 'Z390 Gaming X', 'image\\motherboard1.png', 450.06);

-- --------------------------------------------------------

--
-- Table structure for table `transaction1`
--

CREATE TABLE `transaction1` (
  `TRANSACTIONid` int(255) NOT NULL,
  `productid` int(200) NOT NULL,
  `userid` int(200) NOT NULL,
  `quantity` int(255) NOT NULL,
  `price` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `transaction1`
--

INSERT INTO `transaction1` (`TRANSACTIONid`, `productid`, `userid`, `quantity`, `price`) VALUES
(96, 1, 4, 2, 1200),
(108, 1, 8, 5, 3000),
(109, 1, 4, 5, 3000),
(110, 1, 4, 5, 3000),
(111, 5, 4, 8, 3600),
(112, 1, 4, 2, 1200),
(113, 3, 4, 5, 2695),
(114, 1, 4, 3, 1800),
(117, 5, 9, 3, 1350),
(118, 1, 9, 3, 1800),
(119, 2, 9, 1, 975);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `name` varchar(250) NOT NULL,
  `type` varchar(250) NOT NULL,
  `password` varchar(20) NOT NULL,
  `gmail` varchar(150) NOT NULL,
  `id` int(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`name`, `type`, `password`, `gmail`, `id`) VALUES
('kokyaw', 'usertype', 'heinhtetaung', 'localhost', 4),
('kkk', 'usertype', '123', 'kkk@gmail.com', 8),
('yakouk', 'usertype', 'gogo', 'yakouk@gmail.com', 9),
('yuco', 'usertype', '111111', 'gg@gmail.com', 12),
('yuco', 'usertype', '111111', 'gg@gmail.com', 13),
('Sai Ks', 'usertype', '666666', 'sai@gmail.com', 14),
('poland', 'usertype', '123', 'poland@gmail.com', 15),
('io', 'usertype', '123', 'io@gmail.com', 16);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `addtocart`
--
ALTER TABLE `addtocart`
  ADD PRIMARY KEY (`transactionid`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transaction1`
--
ALTER TABLE `transaction1`
  ADD PRIMARY KEY (`TRANSACTIONid`),
  ADD KEY `productid` (`productid`),
  ADD KEY `userid` (`userid`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `transaction1`
--
ALTER TABLE `transaction1`
  MODIFY `TRANSACTIONid` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=122;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `transaction1`
--
ALTER TABLE `transaction1`
  ADD CONSTRAINT `transaction1_ibfk_1` FOREIGN KEY (`productid`) REFERENCES `product` (`id`),
  ADD CONSTRAINT `transaction1_ibfk_2` FOREIGN KEY (`userid`) REFERENCES `user` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
