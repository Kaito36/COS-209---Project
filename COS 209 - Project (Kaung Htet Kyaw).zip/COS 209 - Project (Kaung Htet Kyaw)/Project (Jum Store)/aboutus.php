<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <script type="text/javascript" src="js/jquery.min.js"></script> 
  
 
     <script type="text/javascript" src="js/bootstrap.min.js"></script> 
</head>
<body>
<?php
session_start();
$conn = mysqli_connect("localhost","heinhtetaung","heinhtetaung","oswebsite");





if (isset($_SESSION['uin'] ) OR isset($_SESSION['pd'])) {
	
	$gmailname = $_SESSION['uin'];
$email = " ";
$password = $_SESSION['pd'];
$name = $type = '';
$id= 0;




$sql = "SELECT * FROM user WHERE gmail = '$gmailname' AND password = '$password'";
$result = mysqlI_query($conn, $sql);
if (mysqli_num_rows($result) > 0) {
	while($row = mysqli_fetch_assoc($result))
	{
		$name = $row["name"];
		$type = $row["type"];
		$email = $row["gmail"];
    	$id   = $row["id"];

		
	}
}
}



?>






<div class="container-fluid">
	<div class="container-fluid">
	<ul class="nav nav-tabs">
		 <li><img src="image\logofor.png" style="height: 80px"> </li>
  <li><a href="welcome.php">Home</a></li>
  <li><a href="product.php">Product</a></li>
  <li class="active"><a href="aboutus.php">About us</a></li>
 <?php
  if (isset($_SESSION['uin'] ) OR isset($_SESSION['pd'])) {
?>
   <!--   <li><a href="login.php">Login</a></li> --->
     <!--<li><a href="signup.php">Signup</a></li> ----->


 <?php
 
}
else{

?>
 <li><a href="login.php">Login</a></li>
 <li><a href="signup.php">Signup</a></li>

<?php
}
 ?> 
<?php
  if (isset($_SESSION['uin'] ) OR isset($_SESSION['pd'])) {
?>
  <li class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown">
  	<?php 
  
  		echo $email;
   

?>
</a> 

<ul class="dropdown-menu">
	<li><a href="account.php"> Account </a></li>
	<li><a href="logout.php"> Log Out </a></li>
</ul>
<?php
}

?>
</ul>
</li>
</div>
</div>


<div class="container-fluid">
	<div style="padding-left: 1000px"><img src="image\logofor.png"> </div>
	<div>
		<p style="text-align: center; font-size: 40px"> JUM STORE is a worwide IT products and Accessories company. We sell a product 24/7. We only sell best quality product. We are selling Motherboard, Graphic Card and CPU. Sooner or Later, We are palnning to sell mousepad, mouse and case and so on.</p>
	</div>
</div>










</body>
</html>