
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <script type="text/javascript" src="js/jquery.min.js"></script> 
  
 
     <script type="text/javascript" src="js/bootstrap.min.js"></script> 
</head>
<body>

<?php


$connect = new mysqli("localhost","heinhtetaung","heinhtetaung","oswebsite");

if (isset($_POST['submit'])) {
	$gmailname = $_POST['gmail'];
	$password = $_POST['pd'];
	$username = $_POST['uname'];
	$utype	= "usertype";
	
	$stmt = $connect->prepare("INSERT INTO user(name,type,password,gmail) VALUES(?,?,?,?)");

	//$connection = new mysqli("localhost","heinhtetaung","heinhtetaung","oswebsite");
	$stmt->bind_param("ssss", $username, $utype, $password, $gmailname);
	$stmt->execute();

	//$query = "INSERT INTO user(name,type,password,gmail) VALUES ('$username','$utype','$password','$gmailname')";


	// $result = mysqli_query($connect, $stmt);

	if ($stmt) {
		$stmt->close();
		mysqli_close($connect);
		header("Location: login.php");
	}
	

}

?>

<div class="container-fluid">
	<ul class="nav nav-tabs">
		 <li><img src="image\logofor.png" style="height: 80px"> </li>
  <li><a href="#">Home</a></li>
  <li><a href="product.php">Product</a></li>
  <li><a href="aboutus.php">About us</a></li>
  <li><a href="login.php">Login</a></li>
  <li class="active"><a href="signup.php">Signup</a></li>
</ul>
</div>

<div class="container-fluid">
	<div class="row">
		<div class="col-lg-4"></div>
		<div class="col-lg-4">
<form action="signup.php" method="post">
			<div class="input-group" style="padding-top: 30px;">
			<input type="text" name="gmail" class="form-control" placeholder="Gmail">
						
			<input type="password" name="pd" class="form-control" placeholder="password">

			<input type="text" name="uname" class="form-control" placeholder="Username">

			<input type="submit" name="submit" class="btn btn-primary" value="Submit">


			</div>
		</form>
		</div>


		<div class="col-lg-4"></div>
	</div>	
</div>





</body>
</html>