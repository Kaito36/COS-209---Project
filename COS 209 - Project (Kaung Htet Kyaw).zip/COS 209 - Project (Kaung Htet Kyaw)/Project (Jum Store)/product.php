<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <script type="text/javascript" src="js/jquery.min.js"></script> 
  
 
     <script type="text/javascript" src="js/bootstrap.min.js"></script> 
</head>
<body>
<?php
session_start();
$conn = mysqli_connect("localhost","heinhtetaung","heinhtetaung","oswebsite");





if (isset($_SESSION['uin'] ) OR isset($_SESSION['pd'])) {
	
	$gmailname = $_SESSION['uin'];
$email = " ";
$password = $_SESSION['pd'];
$name = $type = '';
$id= 0;




$sql = "SELECT * FROM user WHERE gmail = '$gmailname' AND password = '$password'";
$result = mysqlI_query($conn, $sql);
if (mysqli_num_rows($result) > 0) {
	while($row = mysqli_fetch_assoc($result))
	{
		$name = $row["name"];
		$type = $row["type"];
		$email = $row["gmail"];
    	$id   = $row["id"];

		
	}
}
}



?>






<div class="container-fluid">
	<div class="container-fluid">
	<ul class="nav nav-tabs">
		 <li><img src="image\logofor.png" style="height: 80px"> </li>
  <li><a href="welcome.php">Home</a></li>
  <li class="active"><a href="product.php">Product</a></li>
  <li><a href="aboutus.php">About us</a></li>
 <?php
  if (isset($_SESSION['uin'] ) OR isset($_SESSION['pd'])) {
?>
   <!--   <li><a href="login.php">Login</a></li> --->
    <!--<li><a href="signup.php">Signup</a></li> ----->

 <?php
 
}
else{

?>
 <li><a href="login.php">Login</a></li>
 <li><a href="signup.php">Signup</a></li>
<?php
}
 ?>
  
<?php
  if (isset($_SESSION['uin'] ) OR isset($_SESSION['pd'])) {
?>
  <li class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown">
  	<?php 
  
  		echo $email;
   

?>
</a> 

<ul class="dropdown-menu">
	<li><a href="account.php"> Account </a></li>
	<li><a href="logout.php"> Log Out </a></li>
</ul>
<?php
}

?>
</li>
</ul>
</div>
</div>




	<?php


		$sql1 = "SELECT * FROM product";

		$result1 = mysqli_query($conn, $sql1); // product data
		if(mysqli_num_rows($result1) > 0) {
			 while ($row1 = mysqli_fetch_array($result1)) {
			 ?>


			 <div class="container-fluid">
			 	<form action="product.php" method="post">
			 		<div class="row">
			 	<div class="col-md-1">
			 		<br>
			 		<input type="hidden" name="hn" value="<?php	echo $row1["id"]; ?>">
			 		<h5> ID Type:  <?php echo $row1["id"]; ?></h5>
 			 		<h5> Product Type:  <?php echo $row1["type"]; ?></h5>
			 	</div>
			 		<br>
			 	<div class="col-md-1">
			 		<h5> <?php echo $row1["pname"]; ?></h5>
			 	</div>
			 		<br>
			 	<div class="col-md-3">
			 		<img style="width: 300px; height: 200px" src="<?php echo $row1["image"];  ?>"> </img>
			 	</div>
			 		<br>
			 	<div class="col-md-1">
			 		<input type="hidden" name="p1" value="<?php	echo $row1["price"]; ?>">

			 		<h5> <?php echo $row1["price"]; ?></h5>
			 	</div>


				<div class="col-md-3">
			 		<input type="submit" name="buy1" value="Add to Cart">
			 	</div>
			 	<div class="col-md-3">
			 		<input type="input" name="quan" placeholder="Enter your quantity!">
			 	</div>
			</form>
		</div>



<?php


}
}





	?>





<?php



	
$p1 = 0;
if (isset($_POST['buy1'])) {
	if (isset($id)) {
		//var_dump($_POST['p1']);
	// $qu = filter_input(INPUT_POST, 'quan', FILTER_VALIDATE_INT);
	// $p2 = filter_input(INPUT_POST, 'hn', FILTER_VALIDATE_INT);

	// $pe = filter_input(INPUT_POST, $_POST["productPrice"], FILTER_VALIDATE_INT);
	$price = (int)$_POST['p1'];
	$quantity = (int)$_POST['quan'];
	$total  =  $price * $quantity;

	//var_dump($id);


$sql3 = "INSERT INTO transaction1 (productid,userid,quantity,price) VALUES ('". $_POST['hn'] ."', '". $id."', '".$quantity ."', '". $total ."')"; 
//echo $sql3;
$result3 = mysqli_query($conn, $sql3);
$mess = "Order Completed";
echo "<script type='text/javascript'> alert('$mess'); </script>";
	}
	else
	{
		$message = "Please Login First!";
			echo "<script type='text/javascript'>alert('$message');</script>";
	}





}









?>








</body>
</html>