
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <script type="text/javascript" src="js/jquery.min.js"></script> 
  
 
     <script type="text/javascript" src="js/bootstrap.min.js"></script> 

</head>
<body>

	<?php
$connect = new mysqli("localhost","heinhtetaung","heinhtetaung","oswebsite");

	if (isset($_POST['submit'])) {	
	
		//$gmailname = mysql_real_escape_string($_POST['uin']);
		//$password = mysql_real_escape_string($_POST['uin']);
		$gmailname = $_POST['uin'];
		$password  = $_POST['pd'];
		
		
$stmt = $connect->prepare("SELECT * FROM user WHERE gmail = ? AND password = ?");

	
	$stmt->bind_param("ss",$gmailname,$password);
	$stmt->execute();

	

	if ($stmt) {
		$stmt->close();
		mysqli_close($connect);
		header("Location: welcome.php");
		session_start();
		$_SESSION['uin'] = $gmailname;
			$_SESSION['pd']  = $password;
	}


	}

?>

<div class="container-fluid">
<div class="container-fluid">
	<ul class="nav nav-tabs">
	<li><img src="image\logofor.png" style="height: 80px"> </li>
  <li><a href="welcome.php">Home</a></li>
  <li><a href="product.php">Product</a></li>
  <li><a href="aboutus.php">About us</a></li>
  <li class="active"><a href="login.php">Login</a></li>
  <li><a href="signup.php">Signup</a></li>
</ul>

</div>



<div class="container-fluid">
	<div class="row">
		<div class="col-lg-4"></div>
		<div class="col-lg-4">
			<form action="login.php" method="post">
			<div class="input-group" style="padding-top: 30px;">
			<input type="text" name="uin" class="form-control" placeholder="Gmail">
						
					<input type="password" name="pd" class="form-control" placeholder="password">

					<input type="hidden" name="hd" class="form-control">

					<input type="submit" name="submit" class="btn btn-primary" value="Submit">

			</div>

		</form>

		</div>
		<div class="col-lg-4"></div>
	</div>	
</div>

</div>
</body>
</html>