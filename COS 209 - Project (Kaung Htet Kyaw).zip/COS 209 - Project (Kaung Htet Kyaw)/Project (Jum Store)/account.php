<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <script type="text/javascript" src="js/jquery.min.js"></script> 
  
 
     <script type="text/javascript" src="js/bootstrap.min.js"></script> 
</head>
<body>
<?php
session_start();
$conn = mysqli_connect("localhost","heinhtetaung","heinhtetaung","oswebsite");
$gmailname = $_SESSION['uin'];
$password  = $_SESSION['pd'];
$uid = 0;
$i = 0;
$email = " ";
$name = $type = '';
$resultarray = array();
$transc = $pid = $quantity = $price = 0; 
$sql = "SELECT * FROM user WHERE gmail = '$gmailname' AND password = '$password'";
$result = mysqlI_query($conn, $sql);
if (mysqli_num_rows($result) > 0) {
	while($row = mysqli_fetch_assoc($result))
	{
		$name = $row["name"];
		$type = $row["type"];
		$email = $row["gmail"];
		$uid  = $row["id"];

		
	}
}


$sql1 = "SELECT * FROM transaction1 WHERE userid = $uid";
$result1 = mysqlI_query($conn, $sql1);
$num_row = mysqlI_num_rows($result1);




?>



<div class="container-fluid">
	<div class="container-fluid">
	<ul class="nav nav-tabs">
		 <li><img src="image\logofor.png" style="height: 50px"> </li>
  <li><a href="welcome.php">Home</a></li>
  <li><a href="product.php">Product</a></li>
  <li><a href="aboutus.php">About us</a></li>
<?php
  if (isset($_SESSION['uin'] ) OR isset($_SESSION['pd'])) {
?>
   <!--   <li><a href="login.php">Login</a></li> --->
  <!--<li><a href="signup.php">Signup</a></li> ----->

 <?php
 
}
else{

?>
 <li><a href="login.php">Login</a></li>
<li><a href="signup.php">Signup</a></li>
<?php
}
 ?>

<?php
  if (isset($_SESSION['uin'] ) OR isset($_SESSION['pd'])) {
?>
  <li class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown">
  	<?php 
  
  		echo $email;
   

?>
</a> 

<ul class="dropdown-menu">
	<li><a href="account.php"> Account </a></li>
	<li><a href="logout.php"> Log Out </a></li>
</ul>
<?php
}

?>
  </li>
</ul>



</div>

<div class="container-fluid">
	 <div class="col-lg-4"></div>
	 <div class="col-lg-4">
	 	<h2 style="color: #99d6ff"> Account Name: <?php echo $email ?></h2>
	 	<br>
	 	<h1 style="color: #99d6ff"> Order Record </h1>
	 	<br>
	 	<div class="col-lg-3" style="color: #99d6ff"> TRANSACTION ID</div>
	 	<div class="col-lg-2" style="color: #99d6ff"> Product ID </div>
	 	<div class="col-lg-2" style="color: #99d6ff"> User ID </div>
	 	<div class="col-lg-2" style="color: #99d6ff"> Quantity </div>
	 	<div class="col-lg-2" style="color: #99d6ff"> Price </div>

	 	<?php


	 
if (mysqlI_num_rows($result1) > 0) {

    while ($values = mysqli_fetch_assoc($result1)) {
    	echo '<div class = "row">';
        echo '<div class="col-lg-3">'. $values['TRANSACTIONid'] . ' </div>';
        echo  '<div class="col-lg-3">'. $values['productid'] . ' </div>';
        echo   '<div class="col-lg-2">'.$values['userid'] . ' </div>' ;
        echo  '<div class="col-lg-2">'.  $values['quantity']  . ' </div>';
        echo   '<div class="col-lg-2">'. $values['price'] . ' </div>';
        echo '</div>';
    
    }
}
	 	


	 	?>

	 	<div class="container-fluid">
	 		<a href="logout.php"><input type="button" name="logout" value="Logout"> </a>
	 	</div>

	 </div>

	 <div class="col-lg-4"></div>

</div>




</div>



</body>
</html>