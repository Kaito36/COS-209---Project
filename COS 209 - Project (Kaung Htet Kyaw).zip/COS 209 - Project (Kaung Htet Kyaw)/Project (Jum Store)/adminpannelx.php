
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <script type="text/javascript" src="js/jquery.min.js"></script> 
  
 
     <script type="text/javascript" src="js/bootstrap.min.js"></script> 

</head>
<body>

<?php

       $connection = new mysqli("localhost","heinhtetaung", "heinhtetaung","oswebsite");

if (isset($_POST['deltu'])) {
	$uerid = (int)$_POST['uid'];
		var_dump($uerid);
		$sql = "DELETE FROM user WHERE id ='".$uerid."'";
		$sql1 = "DELETE FROM transaction1 WHERE userid ='".$uerid."'";
	
		
		$result1 = mysqli_query($connection, $sql1);
		$result = mysqli_query($connection, $sql);

		if ($result AND $result1) {
			$message = "Completed delete all user";
			echo "<script type='text/javascript'>alert('$message');</script>";
		}else
		{
			var_dump($result);
			var_dump($result1);
		}
}


if (isset($_POST['seleu'])) {

		$sql1 = "SELECT * FROM user";
		$result = mysqli_query($connection, $sql1);

if (mysqli_num_rows($result) > 0) {

  while($row = mysqli_fetch_assoc($result)) {
    echo $row["name"] ." "; 
    echo $row["type"] ." ";
    echo $row["password"]." ";
    echo $row["gmail"]."  ";
    echo $row["id"]."<br>";
  }
}
}


if (isset($_POST['delp'])) {
	$uerid = (int)$_POST['pid'];
		var_dump($uerid);
		$sql = "DELETE FROM product WHERE id ='".$uerid."'";
		$sql1 = "DELETE FROM transaction1 WHERE productid ='".$uerid."'";
	
		
		$result1 = mysqli_query($connection, $sql1);
		$result = mysqli_query($connection, $sql);

		if ($result AND $result1) {
			$message = "Completed delete all product";
			echo "<script type='text/javascript'>alert('$message');</script>";
		}else
		{
			var_dump($result);
			var_dump($result1);
		}
}

if (isset($_POST['prod'])) {

		$sql1 = "SELECT * FROM product";
		$result = mysqli_query($connection, $sql1);

if (mysqli_num_rows($result) > 0) {

  while($row = mysqli_fetch_assoc($result)) {
    echo $row["id"] ." "; 
    echo $row["type"] ." ";
    echo $row["pname"]." ";
    echo $row["image"]."  ";
    echo $row["price"]."<br>";
  }
}
}

if (isset($_POST['transc'])) {

		$sql1 = "SELECT * FROM transaction1";
		$result = mysqli_query($connection, $sql1);

if (mysqli_num_rows($result) > 0) {

  while($row = mysqli_fetch_assoc($result)) {
    echo $row["TRANSACTIONid"] ." "; 
    echo $row["productid"] ." ";
    echo $row["userid"]." ";
    echo $row["quantity"]."  ";
    echo $row["price"]."<br>";
  }
}
}





?>



<div class="container-fluid">
	<div class="row">
		<form action="adminpannelx.php" method="post">
			<div class="input-group" style="padding-top: 30px;">


				<form action="adminpannelx.php" method="post">

				<input type="submit" name="transc" class="btn btn-primary" value="View All Transaction">



				<br><br><br>
				<input type="text" name="uid" placeholder="User ID">
			
				<input type="submit" name="deltu" class="btn btn-primary" value="Delete User">
				<input type="submit" name="seleu" class="btn btn-primary" value="View User">

				<br><br><br>

				<input type="text" name="pid" placeholder="Product ID">
			
				<input type="submit" name="delp" class="btn btn-primary" value="Delete Product">
				<input type="submit" name="prod" class="btn btn-primary" value="View Product">
				</form>








			</div>
			
		</form>
	</div>




</div>
</body>
</html>